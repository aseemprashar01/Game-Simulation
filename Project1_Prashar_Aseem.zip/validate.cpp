/****************************************************************************************************
** Name: Aseem Prashar
** Date: 1/14/18
** Description: validate.cpp is the Validate function implementation file.
1. The function has a return type of int.
2. The function takes no arguements.
3. The function gets the user input and checks if it is an integer.If yes it return that number 
   if not it prompts the user to enter input again.
*****************************************************************************************************/


#include <iostream>
#include <cctype>
#include <string>
#include <iomanip>
#include"validate.hpp"
#include <cstring>
#include <cstdlib>
using namespace std;

int Validate()
{
	char input[100]; 
	//bool validate(char[], int);
	int len;
	
	cin >> input;
	
	len = strlen(input); 

	while (!validate(input, len))
	{
		cout << "\nYou can only have a positive integer as input" << endl;
		cout << "Enter your input " << endl;
		cin >> input;

		len = strlen(input);
	}
	int num = atoi(input);
	return num;
}

bool validate(char inp[], int len)
{
	int i = 0;

	for (i = 0; i < len; i++)
	{
		if (!isdigit(inp[i]))
			return false;
	}
	return true;
}
