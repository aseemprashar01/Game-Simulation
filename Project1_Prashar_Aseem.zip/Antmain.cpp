/********************************************************************************************
** Name: Aseem Prashar
** Date: 1/12/18
** Description: This program simulates Langton Ant.
1. It displays a menu at the start with 2 options: to start the simulation or quit.
2. After the simulation again a menu appers asking user to play again or quit.
******************************************************************************************/

#include<iostream>
#include"Ant.hpp"
#include<cstdlib>
#include<ctime>
#include"validate.hpp"
#include"Menu.hpp"

using namespace std;


int main()
{
	int choice = 0;
	menu1(choice);

	while (choice >= 0)
	{
		if (choice == 1)
		{
			int bRow, bCol, aRow, aCol, steps;

			cout << "Enter the number of rows for the board" << endl;
			bRow= Validate();
			
			cout << "Enter the number of coloumns for the board" << endl;
			bCol = Validate();

			cout << "Enter number of steps in simulation" << endl;
			steps = Validate();

			cout << "Do you want to randomly allocate ant row and location hit 1 for yes 2 for no";
			choice = Validate();
			while (choice < 1 || choice>2)
			{
				cout << "Invalid input. Please reenter hit 1 for yes and 2 for no ";
				choice = Validate();
			}
			if (choice == 1)
			{
				cout << "You will get random location for ant" << endl;
				srand(time(NULL));
				aRow = rand() % (bRow);                                  // this will assign random location for ant's row.
				aCol = rand() % (bCol);                                  // this will assign random location for ant's col.
				cout << "Row location for ant is:" << aRow << endl;
				cout << "Col location for ant is: " << aCol << endl;
								
			}
			else 
			{			
				
				cout << "Enter the starting row of the ant";
				aRow = Validate();
				cout << "Enter the starting coloumn of the ant";
				aCol = Validate();
				while (aRow < 0 || aRow >= bRow || aCol < 0 || aCol >= bCol)
				{
					cout << "Your ant location is out of bounds. Please reenter the information again." << endl;
					cout << "Enter the starting row of the ant";
					aRow = Validate();
					cout << "Enter the starting coloumn of the ant";
					aCol = Validate();
				}
			}
			
			Ant a(bRow, bCol, aRow, aCol, steps);         //Initialize the ant constructor with the user provided inputs.
			a.play();				     // Play function will print the board after every move and updates the ant position after the move.
			menu2(choice);	
		}
		else if (choice == 2)
		{
			cout << "You chose to quit the program"<<endl;
			break;
		}
		else
		{
			cout << "Invalid input" << endl;
			menu1(choice);
		}
	}
	
      //system("Pause");

	return 0;
}


