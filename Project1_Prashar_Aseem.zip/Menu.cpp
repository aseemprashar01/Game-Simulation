/****************************************************************************************************
** Name: Aseem Prashar
** Date: 1/14/18
** Description: Menu.cpp is the Validate function implementation file.
1. The function has a return type of void.
2. The functions take a chracter by reference as an arguement.
3. The functions prompt the user with a menu.
*****************************************************************************************************/
#include"Menu.hpp"
#include"validate.hpp"
#include<iostream>

using namespace std;

void menu1(int &ch)
{
	cout << "Select your option from the given menu." << endl;
	cout << "1. Start Langton Ant simulation" << endl;
	cout << "2. Quit" << endl;
	ch = Validate();

}
void menu2(int &ch)
{
	cout << "Select your option from the given menu." << endl;
	cout << "1. Play again" << endl;
	cout << "2. Quit" << endl;

	ch = Validate();

}
