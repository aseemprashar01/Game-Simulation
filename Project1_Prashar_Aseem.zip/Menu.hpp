/********************************************************************************************
** Name: Aseem Prashar
** Date: 1/14/18
** Description: Menu.hpp is the validate function prototype definition file.
********************************************************************************************/
#ifndef MENU_HPP
#define MENU_HPP

void menu1(int &);
void menu2(int &);


#endif
