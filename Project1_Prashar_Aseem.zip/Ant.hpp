/********************************************************************************************
** Name: Aseem Prashar
** Date: 1/12/18
** Description: Ant.hpp is the Ant class specification file.
********************************************************************************************/

#ifndef ANT_HPP
#define ANT_HPP
enum antOrient {Up,Down,Left,Right};                 // Different ant orientation possible.
class Ant
{
private:
	char **Board;
	int boardRow;
	int boardCol;
	int antRowloc;
	int antColloc;
	int numSteps;
	antOrient antDir;                              // ant orientation

public:
	void readBoard();
	Ant(int ,int,int ,int,int);
	void printBoard() const;
	void moveAnt();
	void play();
	~Ant();



};
#endif

