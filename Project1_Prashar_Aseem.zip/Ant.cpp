/**************************************************************************
** Name: Aseem Prashar
** Date: 01/12/18
** Description: Ant.cpp is the Ant class implementation file.
***************************************************************************/


#include<iostream>
#include"Ant.hpp"
using namespace std;

Ant::Ant(int bRow,int bCol,int antRow,int antCol,int steps)                 // Ant constructor sets the value for data members.
{
	boardRow = bRow;
	boardCol = bCol;
	antRowloc = antRow;
	antColloc = antCol;
	readBoard();
	antDir = Up;															// Initial orientation of the ant is taken as UP.
	numSteps = steps;
	//printBoard();
	cout << "This is the starting board" << endl;
	

}
/*****************************************************************************************
								Ant:: readBoard
This function initializes the board with all white spaces.
******************************************************************************************/
void Ant::readBoard()                                                   
{
	Board = new char*[boardRow];
	for (int i = 0; i < boardRow; i++)
		Board[i] = new char[boardCol];

	for (int i = 0; i < boardRow; i++)
	{
		cout << endl;
		for (int j = 0; j < boardCol; j++)
		{
			Board[i][j] = 'w';
		}
			
		
	}
	
}
/*****************************************************************************************************
								Ant:: printBoard
This function displays the board white spaces as ' ' and black spaces as'#' and ant position as '*'

******************************************************************************************************/

void Ant::printBoard() const
{
	
	for (int i = 0; i < boardRow+2; i++)
	{
		for (int j = 0; j < boardCol + 2; j++)
		{
			if ((i == 0) || (i == (boardRow + 1)))
				cout <<'-';
			else if ((j == 0) || (j == (boardCol + 1)))
				cout << '|';
			else if (((i - 1 )== antRowloc)&& ((j - 1) == antColloc))
				cout << '*';
			else if (Board[i - 1][j - 1] == 'w')
				cout << ' ';
			else if (Board[i-1][j-1] == 'b')
				cout << '#';
			
		}
		cout << endl;
	}
}
Ant::~Ant()                                                 // Destructor to delete the board.
{
	for (int i = 0; i < boardRow; i++)
		delete[] Board[i];
	delete[]Board;

}

/*****************************************************************************************************
								Ant:: play
This function runs the game for the number of simulation steps provided by user and at every step 
it displays the board and updates the position of the ant on the board.

******************************************************************************************************/

void Ant::play()
{
	char ch;
	for (int i = 0; i < numSteps; i++)
	{
		printBoard();
		moveAnt();
		
		cout << "Enter a chracter for next step";
		cin >> ch;
		cout << endl;
	}
	printBoard();

}
/*****************************************************************************************************
								Ant:: moveAnt
This function moves the ant according to the following rules:
a. If the ant is on a white space, turn right 90 degrees and change the space to black.
b. If the ant is on a black space, turn left 90 degrees and change the space to white

******************************************************************************************************/

void Ant::moveAnt()
{
	int r=antRowloc, c=antColloc;// r-row c-col
	
	if (Board[r][c] == 'w')                                   // When the ant is on white space.
	{
		Board[r][c] = 'b';
		switch (antDir)
		{
		case Up:                                             // Ant facing UP
			antDir = Right;
			c = c+1;
			if (c == boardCol)                               //edge case Skip the step forward step, make another turn and then continue on. 
			{
				antDir = Left;
				c = boardCol-1;
				Board[r][c] = 'w';
			}
			break;

		case Down:                                           //Ant facing down
			antDir = Left;
			c= c-1;
			if (c < 0)                                        //edge case Skip the step forward step, make another turn and then continue on. 
			{
				antDir = Right;
				c = 0;
				Board[r][c] = 'w';
			}
			break;
			
		case Left:                                         //Ant facing left
			antDir = Up;
			r = r-1;
			if (r < 0)                                     //edge case Skip the step forward step, make another turn and then continue on. 
			{
				antDir = Down;
				r = 0;
				Board[r][c] = 'w';
			}
			break;

		case Right:                                        // Ant facing right
			antDir = Down;
			r=r+1;
			if (r ==boardRow)                             //edge case Skip the step forward step, make another turn and then continue on. 
			{
				antDir = Up;
				r = boardRow-1;
				Board[r][c] = 'w';
			}
			break;
		}
	}
	else                                                  // When Ant is on black space.
	{
		Board[r][c] = 'w';
		switch (antDir)
		{
			case Up:                                     // Ant facing Up
				antDir = Left;
				c = c - 1;
				if (c < 0)                              //edge case Skip the step forward step, make another turn and then continue on. 
				{
					antDir = Right;
					c = 0;
					Board[r][c] = 'b';
				}
				break;
				 
			case Down:                                  // Ant facing Down 
				antDir = Right;
				c = c + 1;
				if (c == boardCol)                     //edge case Skip the step forward step, make another turn and then continue on. 
				{
					antDir = Left;
					c = boardCol - 1;
					Board[r][c] = 'b';
				}
				break;

			case Left:                                 // Ant facing Left
				antDir = Down;
				r = r + 1;
				if (r == boardRow)                     //edge case Skip the step forward step, make another turn and then continue on. 
				{
					antDir = Up;
					r = boardRow - 1;
					Board[r][c] = 'b';
				}
				break;

			case Right:                                // Ant facing right
				antDir = Up;
				r = r - 1;
				if (r < 0)                            //edge case Skip the step forward step, make another turn and then continue on. 
				{
					antDir = Down;
					r = 0;
					Board[r][c] = 'b';
				}
				break;
		}
	}
	antRowloc = r;                                  // Update ant row location
	antColloc = c;                                  // Update ant col location
}